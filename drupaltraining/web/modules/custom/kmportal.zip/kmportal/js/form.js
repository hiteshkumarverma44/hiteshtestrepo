
(function($) {
    Drupal.behaviors.myBehavior = {
      attach: function (context, settings) {
    
        //code starts
        $("#close").click(function() {
          //alert("Hello World");
          window.location.reload();
        });
        $("#close1").click(function() {
          window.location.reload();
        });
        //code ends
      }
    };
    })(jQuery);

    