$(document).ready(function(){
  $(".job-des-comment").click(function(){
    $(".comment-section").toggle();
  });
});